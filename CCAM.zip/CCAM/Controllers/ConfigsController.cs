﻿using CCAM.Data;
using CCAM.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CCAM.Controllers
{
    public class ConfigsController : Controller
    {
        private readonly AppDBContext _context;

        public ConfigsController(AppDBContext context)
        {
            _context = context;
        }

        // GET: Configs
        public async Task<IActionResult> Index()
        {
            return View(await _context.Configs.ToListAsync());
        }

        // GET: Configs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var configs = await _context.Configs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (configs == null)
            {
                return NotFound();
            }

            return View(configs);
        }

        // GET: Configs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Configs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,DBName,DBUID,DBPass,DBPKey,DBIV,DLFolder,ULFolder,SFTPIP,SFTPPath,SFTPUID,SFTPPass,SFTPKey,SFTPIV,UARMFTIP,UARMFTPath,UARMFTUID,UARMFTPass,UARMFTPKey,UARMFTPIV")] Configs configs)
        {
            if (ModelState.IsValid)
            {
                _context.Add(configs);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(configs);
        }

        // GET: Configs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var configs = await _context.Configs.FindAsync(id);
            if (configs == null)
            {
                return NotFound();
            }
            return View(configs);
        }

        // POST: Configs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,DBName,DBUID,DBPass,DBPKey,DBIV,DLFolder,ULFolder,SFTPIP,SFTPPath,SFTPUID,SFTPPass,SFTPKey,SFTPIV,UARMFTIP,UARMFTPath,UARMFTUID,UARMFTPass,UARMFTPKey,UARMFTPIV")] Configs configs)
        {
            if (id != configs.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(configs);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ConfigsExists(configs.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(configs);
        }

        // GET: Configs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var configs = await _context.Configs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (configs == null)
            {
                return NotFound();
            }

            return View(configs);
        }

        // POST: Configs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var configs = await _context.Configs.FindAsync(id);
            if (configs != null)
            {
                _context.Configs.Remove(configs);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ConfigsExists(int id)
        {
            return _context.Configs.Any(e => e.Id == id);
        }
    }
}
