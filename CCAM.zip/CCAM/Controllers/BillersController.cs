﻿using CCAM.Data;
using CCAM.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CCAM.Controllers
{
    [Authorize(Roles = "Admin")]
    public class BillersController : Controller
    {
        private readonly AppDBContext _billercontext;

        public BillersController(AppDBContext billercontext)
        {
            _billercontext = billercontext;
        }

        // GET: Billers
        public async Task<IActionResult> Index()
        {
            return View(await _billercontext.Biller.ToListAsync());
        }

        // GET: Billers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var biller = await _billercontext.Biller
                .FirstOrDefaultAsync(m => m.Id == id);
            if (biller == null)
            {
                return NotFound();
            }

            return View(biller);
        }

        // GET: Billers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Billers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,BillerCode,BillerName,AcctNo1,AcctNo2")] Biller biller)
        {
            if (ModelState.IsValid)
            {
                _billercontext.Add(biller);
                await _billercontext.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(biller);
        }

        // GET: Billers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var biller = await _billercontext.Biller.FindAsync(id);
            if (biller == null)
            {
                return NotFound();
            }
            return View(biller);
        }

        // POST: Billers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,BillerCode,BillerName,AcctNo1,AcctNo2")] Biller biller)
        {
            if (id != biller.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _billercontext.Update(biller);
                    await _billercontext.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BillerExists(biller.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(biller);
        }

        // GET: Billers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var biller = await _billercontext.Biller
                .FirstOrDefaultAsync(m => m.Id == id);
            if (biller == null)
            {
                return NotFound();
            }

            return View(biller);
        }

        // POST: Billers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var biller = await _billercontext.Biller.FindAsync(id);
            if (biller != null)
            {
                _billercontext.Biller.Remove(biller);
            }

            await _billercontext.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BillerExists(int id)
        {
            return _billercontext.Biller.Any(e => e.Id == id);
        }
    }
}
