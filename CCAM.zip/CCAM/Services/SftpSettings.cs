﻿namespace CCAM.Services
{
    public class SftpSettings
    {
        public string Host { get; set; }
        public int Port { get; set; } = 22; // Default SFTP port
        public string Username { get; set; }
        public string Password { get; set; }
        public string SshHostKeyFingerprint { get; set; } // Obtain from a successful connection
    }
}
