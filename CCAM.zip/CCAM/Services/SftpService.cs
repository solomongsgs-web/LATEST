﻿using System.IO;
using System.Runtime.Intrinsics.X86;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using WinSCP;
using SessionOptions = WinSCP.SessionOptions;

namespace CCAM.Services
{
    public class SftpService
    {
        private readonly SftpSettings _settings;
        private readonly ILogger<SftpService> _logger;
        public SftpService(IOptions<SftpSettings> settings, ILogger<SftpService> logger)
        {
            _settings = settings.Value;
            _logger = logger;
        }


        //TESTING CONNECTION
        public bool TestConnection()
        {
            try
            {
                // Setup session options from settings
                var sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = _settings.Host,
                    PortNumber = _settings.Port,
                    UserName = _settings.Username,
                    Password = _settings.Password,
                    SshHostKeyFingerprint = _settings.SshHostKeyFingerprint
                };

                // Log that a connection attempt is being made
                _logger.LogInformation("Attempting to connect to SFTP server: {HostName}", _settings.Host);

                using (var session = new Session())
                {
                    session.Open(sessionOptions);
                    _logger.LogInformation("Successfully connected to SFTP server.");
                    return true;
                }
            }
            catch (SessionRemoteException ex)
            {
                _logger.LogError(ex, "SFTP connection failed with a session exception. Error: {ErrorMessage}", ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred during SFTP connection test. Error: {ErrorMessage}", ex.Message);
                return false;
            }
        }

        public bool TestSftpConnection(string hostName, string userName, string password, string sshHostKeyFingerprint = null)
        {
            try
            {
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = hostName,
                    UserName = userName,
                    Password = password,
                    // Optional: For added security, provide the SshHostKeyFingerprint
                    // You can obtain this from WinSCP when connecting manually for the first time
                    SshHostKeyFingerprint = sshHostKeyFingerprint
                };

                using (Session session = new Session())
                {
                    session.Open(sessionOptions);
                    // If session.Open() completes without throwing an exception, the connection is successful.
                    session.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                // Log the exception for debugging purposes
                Console.WriteLine($"SFTP connection failed: {ex.Message}");
                return false;
            }
        }

    }
}
