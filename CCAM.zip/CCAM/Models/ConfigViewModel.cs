﻿using System.ComponentModel.DataAnnotations;
namespace CCAM.Models
{
    public class Configs 
    {
        public int Id { get; set; }
        [Display(Name = "DB Name")]
        public string? DBName { get; set; }
        [Display(Name = "DB UID")]
        public string? DBUID { get; set; }
        [Display(Name = "DB Password")]
        public string? DBPass { get; set; }
        [Display(Name = "DB PKEY")]
        public string? DBPKey { get; set; }
        [Display(Name = "DB PIV")]
        public string? DBIV { get; set; }
        [Display(Name = "Download Folder")]
        public string? DLFolder { get; set; }
        [Display(Name = "Upload Folder")]
        public string? ULFolder { get; set; }
        [Display(Name = "MFT IP")]
        public string? SFTPIP { get; set; }
        [Display(Name = "MFT Path")]
        public string? SFTPPath { get; set; }
        [Display(Name = "SFTP UID")]
        public string? SFTPUID { get; set; }
        [Display(Name = "SFTP Password")]
        public string? SFTPPass { get; set; }
        [Display(Name = "SFTP PKEY")]
        public string? SFTPKey { get; set; }
        [Display(Name = "SFTP PIV")]
        public string? SFTPIV { get; set; }

        [Display(Name = "UAR MFT IP")]
        public string? UARMFTIP { get; set; }
        [Display(Name = "UAR Report Folder")]
        public string? UARMFTPath { get; set; }
        [Display(Name = "UAR MFT UID")]
        public string? UARMFTUID { get; set; }
        [Display(Name = "UAR MFT Password")]
        public string? UARMFTPass { get; set; }
        [Display(Name = "UAR MFT PKEY")]
        public string? UARMFTPKey { get; set; }
        [Display(Name = "UAR MFT PIV")]
        public string? UARMFTPIV { get; set; }
    }
}
