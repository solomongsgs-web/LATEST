﻿
using System.ComponentModel.DataAnnotations;

namespace CCAM.Models
{
    public class Biller 
    {
        public int Id { get; set; }
        [Display(Name = "Biller Code")]
        public string? BillerCode { get; set; }
        [Display(Name = "Biller Name")]
        public string? BillerName { get; set; }
        [Display(Name = "Account Number 1")]
        public string? AcctNo1 { get; set; }
        [Display(Name = "Account Number 2")]
        public string? AcctNo2 { get; set; }

    }
}
