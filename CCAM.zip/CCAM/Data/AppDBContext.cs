﻿using CCAM.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace CCAM.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {

        }

        public DbSet<Biller> Biller { get; set; }
        public DbSet<Configs> Configs { get; set; }
    }

}
